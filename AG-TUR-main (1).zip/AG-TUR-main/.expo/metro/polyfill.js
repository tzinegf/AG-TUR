global.$$require_external = typeof window === "undefined" ? require : () => null;
