module.exports = $$require_external('node:assert');
