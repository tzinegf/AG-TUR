module.exports = $$require_external('node:tls');
