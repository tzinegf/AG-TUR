module.exports = $$require_external('node:constants');
