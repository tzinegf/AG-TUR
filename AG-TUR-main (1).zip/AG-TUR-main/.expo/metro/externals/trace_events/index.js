module.exports = $$require_external('node:trace_events');
