module.exports = $$require_external('node:string_decoder');
