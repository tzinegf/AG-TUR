module.exports = $$require_external('node:dgram');
