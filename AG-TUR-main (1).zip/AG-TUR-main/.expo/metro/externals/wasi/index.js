module.exports = $$require_external('node:wasi');
