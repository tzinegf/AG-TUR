module.exports = $$require_external('node:console');
