module.exports = $$require_external('node:async_hooks');
