module.exports = $$require_external('node:diagnostics_channel');
