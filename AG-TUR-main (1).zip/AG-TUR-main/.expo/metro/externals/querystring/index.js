module.exports = $$require_external('node:querystring');
