module.exports = $$require_external('node:v8');
