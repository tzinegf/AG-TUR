module.exports = $$require_external('node:cluster');
