module.exports = $$require_external('node:child_process');
