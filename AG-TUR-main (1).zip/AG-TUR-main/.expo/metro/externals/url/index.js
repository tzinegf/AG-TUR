module.exports = $$require_external('node:url');
