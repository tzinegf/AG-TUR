module.exports = $$require_external('node:inspector');
