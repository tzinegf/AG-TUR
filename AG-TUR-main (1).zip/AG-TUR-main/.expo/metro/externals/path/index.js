module.exports = $$require_external('node:path');
