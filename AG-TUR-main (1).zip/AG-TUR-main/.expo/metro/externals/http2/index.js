module.exports = $$require_external('node:http2');
