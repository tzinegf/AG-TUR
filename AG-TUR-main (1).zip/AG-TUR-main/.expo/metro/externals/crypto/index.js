module.exports = $$require_external('node:crypto');
