module.exports = $$require_external('node:domain');
