module.exports = $$require_external('node:timers');
