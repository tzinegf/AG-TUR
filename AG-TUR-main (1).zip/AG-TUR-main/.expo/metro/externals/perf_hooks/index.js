module.exports = $$require_external('node:perf_hooks');
