module.exports = $$require_external('node:zlib');
