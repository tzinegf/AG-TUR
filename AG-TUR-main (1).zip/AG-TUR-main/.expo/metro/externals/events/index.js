module.exports = $$require_external('node:events');
