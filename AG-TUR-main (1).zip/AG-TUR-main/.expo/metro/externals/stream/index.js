module.exports = $$require_external('node:stream');
