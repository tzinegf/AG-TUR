module.exports = $$require_external('node:module');
