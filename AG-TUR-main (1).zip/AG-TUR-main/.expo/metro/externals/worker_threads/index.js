module.exports = $$require_external('node:worker_threads');
