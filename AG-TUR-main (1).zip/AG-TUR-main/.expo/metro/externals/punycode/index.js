module.exports = $$require_external('node:punycode');
