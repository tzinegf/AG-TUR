module.exports = $$require_external('node:fs/promises');
