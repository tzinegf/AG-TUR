module.exports = $$require_external('node:readline');
