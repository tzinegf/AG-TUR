module.exports = $$require_external('node:tty');
