module.exports = $$require_external('node:buffer');
