module.exports = $$require_external('node:https');
